clf
close all
grid on




% Optimal solar flux for canberra kW-hr/m^2/day
% 5.29(annual average)
% 5.72 (October)

% 1.4742 m^2 per panel, of which there are 4



A = 1.4742*20

% Ideal power output for a day is

idealenergy = A*6.6667;



% From BOM maps
% 20MJ/m^2 in act on 17th, 5.556 kw-h/m^2/day
% 24MJ/m^2 in act on 18th, 6.6667 kw-h/m^2/day



% Average power from inverter over 24h
% 728.9772 W

% Calculated daily power
% 17,495 Wh
% 17.495 kWh

% Taking solar panel area as A*4.
% Power for the HTF is 2.6327 kW-h/m^2/day
% This is approximately 2.6




% Date and Time conversion


timestring = cell(length(time5),1)
for i = 1:length(time5)
    tempstring = num2str(time5(i))
    if length(tempstring) == 3
        tempstring = strcat('0',tempstring);
    end
    
    if length(tempstring) == 2
        tempstring = strcat('00',tempstring);
    end
    
    if length(tempstring) == 1
        tempstring = strcat('000',tempstring);
    end
    
    tempstring = strcat(tempstring(1:2),':',tempstring(3:end))
    
    timestring{i} = tempstring;
end

formatIn = 'yyyy_mm_dd HH:MM'


datestring = strcat(date6,{' '},timestring)
serialisedtime = datenum(datestring,formatIn)



subplot(1,2,1)
hold on
timeLS = linspace(time(1),time(end),1000);
flowInt = interp1(time,flow,timeLS,'cubic');
ylim([0,flowInt(end)+1])
ylabel('H2 Flow (NL/h)')
plot(time,flow,'o',timeLS,flowInt,'color','b')
title('Electrolyser Startup')




% Get Production curve from measured cumulitative H2
prodmeas = H2Total - H2Total(1);

% Calculate production based on flow
prodcum = cumtrapz(time,flow) / 60;


% Calculate the average prod (measured and calculated)

prodavg = zeros(1,length(time));
for i=1:length(time)
    prodavg(i)=(prodmeas(i)+prodcum(i))/2;
end



prodcurve = interp1(time,prodavg,timeLS,'cubic');
yyaxis right
ylim([0,prodcurve(end)+1])
ylabel({'H2 (L)';'Temperature (C)'},'color','k')
plot(time,prodavg,'o',timeLS,prodcurve,'-','color','r')

tempsmoothed = interp1(time,temperature,timeLS,'spline')
plot(timeLS,tempsmoothed,'-','color','k')

prodtemp = 20;
line([time(1),time(end)],[prodtemp,prodtemp],'LineStyle','--','color','k')

yyaxis left
% p = InterX([timeLS;tempsmoothed],[timeLS;flowInt])
% scatter(p(1),p(2))

legend('Flow Data','Flow Curve','Production Data', 'Total H2 Curve','Temperature Curve','Operation Temperature','Location','northwest')
grid on

subplot(1,2,2)
hold on
grid on

ylabel('Inverter Output Power (W)') 
powersmoothed = interp1(time,currentPower,timeLS,'pchip')
voltagesmoothed = interp1(time,stackVoltage,timeLS,'pchip')


plot(timeLS,powersmoothed)

plot(timeLS,voltagesmoothed)

% 
% 


figure
grid on
hold on
plot(time,temperature)
scatter(1032,[19.8700000000000])

yyaxis right

plot(timeLS,flowInt)




figure
grid on

% 440 to 1157 corresponds to only the 18th
power18 = currentPower3(440:1157)
time18 = serialisedtime(440:1157)


% 1878 is end of the 19th


hold on

plot(time18,power18,'color','b')
title('Inverter Power - 18th October')
xlabel('Time')
ylabel('Power (W)')

tenmin = 10/24/60
start_time = serialisedtime(440)
end_time = serialisedtime(1157)
ticks = start_time:tenmin:end_time;
set(gca,'XTick',ticks)
datetick('x','HH:MM')
prodpower = 1300;
fill = area(time18(285:489),power18(285:489))
fill.FaceColor = [0,0.6,0.1]

fill2 = area(time18(285:489),power18(285:489),1300,'HandleVisibility','on')
fill2.FaceColor = [0.8,0.8,0.8]
set(fill2,'edgecolor',[0.8,0.8,0.8]);

fill3 = area(time18(285:299),power18(285:299),0,'HandleVisibility','off')
fill3.FaceColor = [0.8,0.8,0.8]
set(fill3,'edgecolor',[0.8,0.8,0.8]);
fill4 = area(time18(463:489),power18(463:489),0,'HandleVisibility','off')
set(fill4,'edgecolor',[0.8,0.8,0.8]);
fill4.FaceColor = [0.8,0.8,0.8]

fill5 = area([time18(285),time18(489)],[1300,1300],'HandleVisibility','off')
fill5.FaceColor = [0,0.6,0.1]

fill6 = area(time18(1:285),power18(1:285),'HandleVisibility','off')
fill6.FaceColor = [0.8,0.8,0.8]

fill7 = area(time18(489:end),power18(489:end),'HandleVisibility','off')
fill7.FaceColor = [0.8,0.8,0.8]

line([time18(1),time18(end)],[prodpower,prodpower],'LineStyle','--','color','k')

line([time18(285),time18(285)],[0,4000],'LineStyle','--','color','g')
line([time18(489),time18(489)],[0,4000],'LineStyle','--','color','r')

plot(time18,power18,'color','b')

% 9:26 AM on the 18th = 440+285 (index)
% 4:16 PM on the 18th = 440+489 (index)
legend('Power (W)','Usable Energy (Wh)','Unutilised Energy (Wh)','Operating Power (W)','Start Time','End Time')

copyfigure = gca

% 18th analysis
areaUC = sum(power18)


% Error in total production calculation
figure
hold on

plot(time, prodcum)
plot(time,H2Total-H2Total(1))
title('H2 Production - Measured vs Calculated')
xlabel('Time (s)')
ylabel('Hydrogen (L)')
legend('Flow Integral','H2 Total from Electrolyser Data','location','northwest')


f2 = figure


a2 = copyobj(copyfigure,f2)
hold on




fill2 = area(time18(299:463),power18(299:463),1300)
fill2.FaceColor = [0.8,0.8,0.8]
fill3 = area(time18(285:299),power18(285:299),0)
fill3.FaceColor = [0,0.6,0.1]
set(fill3,'edgecolor',[0,0.6,0.1]);
fill4 = area(time18(463:489),power18(463:489),0,'HandleVisibility','off')
fill4.FaceColor = [0,0.6,0.1]
set(fill4,'edgecolor',[0,0.6,0.1]);

fill6 = area(time18(285:299),power18(285:299),'HandleVisibility','off')
fill6.FaceColor = [0.8,0.8,0.8]

fill7 = area(time18(463:489),power18(463:489),'HandleVisibility','off')
fill7.FaceColor = [0.8,0.8,0.8]

fill9 = area([time18(285),time18(299)],[1300,1300],'HandleVisibility','off')
fill9.FaceColor = [0,0.6,0.1]

fill10 = area([time18(463),time18(489)],[1300,1300],'HandleVisibility','off')
fill10.FaceColor = [0,0.6,0.1]

fill5 = area([time18(299),time18(463)],[2600,2600])
fill5.FaceColor = [0,0.6,0.1]
set(fill5,'edgecolor',[0.8,0.8,0.8]);






line([time18(1),time18(end)],[prodpower*2,prodpower*2],'LineStyle','--','color','k')
line([time18(1),time18(end)],[prodpower,prodpower],'LineStyle','--','color','k')
line([time18(285),time18(285)],[0,4000],'LineStyle','--','color','g')
line([time18(489),time18(489)],[0,4000],'LineStyle','--','color','r')
line([time18(299),time18(299)],[0,4000],'LineStyle','--','color','g')
line([time18(463),time18(463)],[0,4000],'LineStyle','--','color','r')

plot(time18,power18,'color','b')
title('Inverter Power - 2 Electrolysers')

legend('Power (W)','Usable Energy (Wh)','Unutilised Energy (Wh)','Operating Power (W)','Start Time','End Time')
%299 463



